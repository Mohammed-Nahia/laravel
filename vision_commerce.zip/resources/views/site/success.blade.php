@extends('site.master')

@section('content')

    <main class="ps-main">
      <div class="ps-checkout pt-80 pb-80">
        <div class="ps-container">
            <div class="alert alert-success">
                <h1>Done</h1>
                <p>Your payment was completed successfully</p>
            </div>
        </div>
      </div>
@stop
