@extends('site.master')

@section('content')

    <main class="ps-main">
      <div class="ps-checkout pt-80 pb-80">
        <div class="ps-container">
            <div class="alert alert-danger">
                <h1>Failed</h1>
                <p>Your payment was failed :/</p>
            </div>
        </div>
      </div>
@stop
