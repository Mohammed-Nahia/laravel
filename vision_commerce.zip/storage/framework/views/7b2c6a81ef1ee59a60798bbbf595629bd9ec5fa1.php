<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800"><?php echo e(__('site.All Categories')); ?></h1>
        <a class="btn btn-outline-dark" href="<?php echo e(route('admin.categories.create')); ?>">Add New Category</a>
    </div>

    <?php if(session('msg')): ?>
    <div class="alert alert-<?php echo e(session('type')); ?> alert-dismissible fade show" role="alert">
        <?php echo e(session('msg')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php endif; ?>

    
    <table class="table table-hover table-striped table-bordered">
        <thead>
            <tr class="bg-dark text-white">
                <th>ID</th>
                <th>Name</th>
                <th>Image</th>
                <th>Parent</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    
                    <td><?php echo e($category->trans_name); ?></td>
                    <td>
                        <?php
                            $src = 'https://via.placeholder.com/80';
                            if(file_exists(public_path('uploads/images/categories/'.$category->image))){
                                $src = asset('uploads/images/categories/'.$category->image);
                            }
                        ?>
                        <img width="80" src="<?php echo e($src); ?>" alt="">
                    </td>
                    <td> <?php echo e($category->parent->trans_name??''); ?></td>
                    
                    <td><?php echo e($category->created_at->diffForHumans()); ?></td>
                    <td>
                        <a class="btn btn-sm btn-primary" href="<?php echo e(route('admin.categories.edit', $category->id)); ?>"><i class="fas fa-edit"></i></a>
                        <form class="d-inline" action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center">No Data Found</td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>

    <?php echo e($categories->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\vision_commerce\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>