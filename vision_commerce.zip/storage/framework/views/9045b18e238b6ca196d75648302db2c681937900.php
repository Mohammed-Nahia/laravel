<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800">Deleted Product</h1>
        <a class="btn btn-outline-dark" href="<?php echo e(route('admin.products.index')); ?>">All Products</a>
    </div>

    <?php if(session('msg')): ?>
    <div class="alert alert-<?php echo e(session('type')); ?> alert-dismissible fade show" role="alert">
        <?php echo e(session('msg')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php endif; ?>

    
    <table class="table table-hover table-striped table-bordered">
        <thead>
            <tr class="bg-dark text-white">
                <th>ID</th>
                <th>Name</th>
                <th>Deleted At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    
                    <td><?php echo e($category->trans_name); ?></td>
                    <td><?php echo e($category->deleted_at->diffForHumans()); ?></td>
                    <td>
                        <a class="btn btn-sm btn-primary" href="<?php echo e(route('admin.products.restore', $category->id)); ?>"><i class="fas fa-undo"></i></a>
                        <?php if(Auth::user()->type == 'super-admin'): ?>
                            <a onclick="return confirm('Are you sure?!')" class="btn btn-sm btn-danger" href="<?php echo e(route('admin.products.forcedelete', $category->id)); ?>"><i class="fas fa-times"></i></a>
                        <?php endif; ?>


                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center">No Data Found</td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>

    <?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\vision_commerce\resources\views/admin/products/trash.blade.php ENDPATH**/ ?>