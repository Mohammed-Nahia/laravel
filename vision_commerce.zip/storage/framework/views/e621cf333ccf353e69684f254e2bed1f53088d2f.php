<?php $__env->startSection('content'); ?>

    <main class="ps-main">
      <div class="ps-checkout pt-80 pb-80">
        <div class="ps-container">
            <div class="alert alert-danger">
                <h1>Failed</h1>
                <p>Your payment was failed :/</p>
            </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\vision_commerce\resources\views/site/error.blade.php ENDPATH**/ ?>