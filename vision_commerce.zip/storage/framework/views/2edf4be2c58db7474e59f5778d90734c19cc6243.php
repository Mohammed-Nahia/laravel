<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('site.index')); ?>">
        <div class="sidebar-brand-icon">
            <i class="fas fa-shopping-cart"></i>
        </div>
        <div class="sidebar-brand-text mx-3"><?php echo e(__('site.Vision Commerce')); ?></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span><?php echo e(__('site.Dashboard')); ?></span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link <?php echo e(str_contains(request()->url(), 'categories') ? '' : 'collapsed'); ?>" href="#" data-toggle="collapse" data-target="#collapseCategory"
            aria-expanded="true" aria-controls="collapseCategory">
            <i class="fas fa-fw fa-tags"></i>
            <span><?php echo e(__('site.Categories')); ?></span>
        </a>
        <div id="collapseCategory" class="collapse <?php echo e(str_contains(request()->url(), 'categories') ? 'show' : ''); ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item <?php echo e(request()->routeIs('admin.categories.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.categories.index')); ?>"><?php echo e(__('site.All Categories')); ?></a>
                <a class="collapse-item <?php echo e(request()->routeIs('admin.categories.create') ? 'active' : ''); ?>" href="<?php echo e(route('admin.categories.create')); ?>"><?php echo e(__('site.Add New')); ?></a>
                <a class="collapse-item <?php echo e(request()->routeIs('admin.categories.trash') ? 'active' : ''); ?>" href="<?php echo e(route('admin.categories.trash')); ?>">Trash</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link <?php echo e(str_contains(request()->url(), 'products') ? '' : 'collapsed'); ?>" href="#" data-toggle="collapse" data-target="#collapseProduct"
            aria-expanded="true" aria-controls="collapseProduct">
            <i class="fas fa-fw fa-heart"></i>
            <span><?php echo e(__('site.Products')); ?></span>
        </a>
        <div id="collapseProduct" class="collapse <?php echo e(str_contains(request()->url(), 'products') ? 'show' : ''); ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item <?php echo e(request()->routeIs('admin.products.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.products.index')); ?>"><?php echo e(__('site.All Products')); ?></a>
                <a class="collapse-item <?php echo e(request()->routeIs('admin.products.create') ? 'active' : ''); ?>" href="<?php echo e(route('admin.products.create')); ?>"><?php echo e(__('site.Add New')); ?></a>
                <a class="collapse-item <?php echo e(request()->routeIs('admin.products.trash') ? 'active' : ''); ?>" href="<?php echo e(route('admin.products.trash')); ?>">Trash</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link <?php echo e(str_contains(request()->url(), 'coupons') ? '' : 'collapsed'); ?>" href="#" data-toggle="collapse" data-target="#collapseCoupon"
            aria-expanded="true" aria-controls="collapseCoupon">
            <i class="fas fa-fw fa-percent"></i>
            <span>Coupons</span>
        </a>
        <div id="collapseCoupon" class="collapse <?php echo e(str_contains(request()->url(), 'coupons') ? 'show' : ''); ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item <?php echo e(request()->routeIs('admin.coupons.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.coupons.index')); ?>">All Coupons</a>
                <a class="collapse-item <?php echo e(request()->routeIs('admin.coupons.create') ? 'active' : ''); ?>" href="<?php echo e(route('admin.coupons.create')); ?>"><?php echo e(__('site.Add New')); ?></a>
                <a class="collapse-item <?php echo e(request()->routeIs('admin.coupons.trash') ? 'active' : ''); ?>" href="<?php echo e(route('admin.coupons.trash')); ?>">Trash</a>
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->
<?php /**PATH C:\wamp64\www\vision_commerce\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>