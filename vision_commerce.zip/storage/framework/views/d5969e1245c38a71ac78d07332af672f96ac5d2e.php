<?php $__env->startSection('content'); ?>
    <main class="ps-main">
      <div class="ps-content pt-80 pb-80">
        <div class="ps-container" id="cart-content">
            <h3 class="mb-5">Your Notifications</h3>
            <ul class="list-group">
                <?php $__currentLoopData = $user->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->read_at): ?>
                    <li class="list-group-item"><?php echo e($item->data['title']); ?></li>
                    <?php else: ?>
                    <a href="<?php echo e(route('read_notification', $item->id)); ?>" class="list-group-item list-group-item-danger"><?php echo e($item->data['title']); ?></a>
                    <?php endif; ?>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </ul>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\vision_commerce\resources\views/site/notifications.blade.php ENDPATH**/ ?>