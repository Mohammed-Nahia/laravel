<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 text-gray-800"><?php echo e(__('site.All Products')); ?></h1>
        <a class="btn btn-outline-dark" href="<?php echo e(route('admin.products.create')); ?>">Add New Product</a>
    </div>

    <?php if(session('msg')): ?>
    <div class="alert alert-<?php echo e(session('type')); ?> alert-dismissible fade show" role="alert">
        <?php echo e(session('msg')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php endif; ?>

    
    <table class="table table-hover table-striped table-bordered">
        <thead>
            <tr class="bg-dark text-white">
                <th>ID</th>
                <th>Name</th>
                <th>Image</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Views</th>
                <th>Category</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    
                    <td><?php echo e($product->trans_name); ?></td>
                    <td>
                        <?php
                            $src = 'https://via.placeholder.com/80';
                            if(file_exists(public_path('uploads/images/products/'.$product->image))){
                                $src = asset('uploads/images/products/'.$product->image);
                            }
                        ?>
                        <img width="80" src="<?php echo e($src); ?>" alt="">
                    </td>
                    
                    <td> <?php echo e($product->price); ?></td>
                    <td> <?php echo e($product->quantity); ?></td>
                    <td> <?php echo e($product->views); ?></td>
                    <td> <?php echo e($product->category->trans_name??''); ?></td>
                    
                    <td><?php echo e($product->created_at->diffForHumans()); ?></td>
                    <td>
                        <a class="btn btn-sm btn-primary" href="<?php echo e(route('admin.products.edit', $product->id)); ?>"><i class="fas fa-edit"></i></a>
                        <form class="d-inline" action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center">No Data Found</td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>

    <?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\vision_commerce\resources\views/admin/products/index.blade.php ENDPATH**/ ?>