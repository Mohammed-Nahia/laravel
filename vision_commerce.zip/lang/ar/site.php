<?php

return [
    'Vision Commerce' => 'متجر',
    'Dashboard' => 'الرئيسية',
    'Categories' => 'الاقسام',
    'All Categories' => 'جميع الاقسام',
    'Add New' => 'اضافة جديد',
    'Products' => 'المنتجات',
    'All Products' => 'جميع المنتجات',
    'Profile' => 'الملف الشخصي',
    'Logout' => 'تسجيل خروج',
    'Edit Category' => 'تعديل القسم'
];
