<?php

return [
    'Vision Commerce' => 'Vision Commerce',
    'Dashboard' => 'Dashboard',
    'Categories' => 'Categories',
    'All Categories' => 'All Categories',
    'Add New' => 'Add New',
    'Products' => 'Products',
    'All Products' => 'All Products',
    'Profile' => 'Profile',
    'Logout' => 'Logout',
    'Edit Category' => 'Edit Category'
];
